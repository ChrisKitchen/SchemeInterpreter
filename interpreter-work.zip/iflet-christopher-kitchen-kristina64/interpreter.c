#include <stdlib.h>
#include <stdio.h>
#include "tokenizer.h"
#include "value.h"
#include "linkedlist.h"
#include "talloc.h"
#include <assert.h>
#include <string.h>
#include "parser.h"

//what does this function do??



/*Value *eval(Value *tree, Frame *frame) {
   switch (tree->type)  {
     case INT_TYPE: {
        ...
        break;
     }
     case ......: {
        ...
        break;
     }  
     case SYMBOL_TYPE: {
        return lookUpSymbol(tree, frame);
        break;
     }  
     case CONS_TYPE: {
        Value *first = car(tree);
        Value *args = cdr(tree);

        // Sanity and error checking on first...

        if (!strcmp(first->s,"if")) {
            result = evalIf(args,frame);
        }

        // .. other special forms here...

        else {
           // not a recognized special form
           fprintf(stdout,"ERROR");
        }
        break;
     }

      ....
    }    
    ....
}

Value *evalIf(Value *args, Frame *frame){
  
}*/


/*
  input of tree and frame 
  
  if car(tree) == "if":
    if (eval(cadr(tree))) == true:
        eval(car(cdr(cdr tree)))
    else:
        eval(cadddr tree);

  if car(tree) == "let":
    Value *newBinding;
    newBinding = cons(car(cdr tree),car(cdr cdr tree));
    bindings = cons(newBinding, binding);
    Frame newFrame;
    newFrame.parent = Frame;
    newFrame.bindings = bindings;
    eval(cdr(tree),newFrame);
    







*/
int isTrue(Value *val){
  // if(cdr(val) == NULL || cdr(cdr(val)) == NULL){
  //   printf("Evaluation Error");
  //   texit(0);
  // }
  if (val->type == BOOL_TYPE){
    if(val->i == 1){
      return 1;
    }else if(val->i == 0){
      return 0;
    }
  } else{
    printf("Evaluation Error");
    texit(0);
  }

  return 0;
}


Value *lookupSymbol(Value *symbol, Value *bindings, Frame *frame){
  while(frame != NULL){
    while(bindings->type != NULL_TYPE){
      Value *bargs = car(bindings);
      if((!strcmp(car(bargs)->s,symbol->s))){
        return cdr(bargs);
      }else{
        bindings = cdr(bindings);
      }
    }
    if(frame->parent != NULL){
      frame = frame->parent;
      bindings = frame->bindings;
    }
    else{
      printf("Evaluation Error: symbol undefined");
      texit(0);
    }
  }
  
  printf("Evaluation Error: symbol undefined");
  texit(0);
  return NULL;
}
int lookupSymbolTwo(Value *symbol, Value *bindings, Frame *frame){
  // printf("symbol:  %s  ",symbol->s);
  while(frame != NULL){
    // printf("? \n");
    while(bindings->type != NULL_TYPE){
      // printf("! \n");
      // printf("%s",car(car(bindings))->s);
      // printf("%s",symbol->s);
      // Value *bargs = car(bindings);
      if(!strcmp(car(car(bindings))->s,symbol->s)){

        return 1;
      }
      
      bindings = cdr(bindings);
    }
    // if(frame->parent != NULL){
    //   frame = frame->parent;
    //   bindings = frame->bindings;
    // }else{
      return 0;
    // }
  }
  return 0;
}
// Value *InputType(Value *input){ //find out what we're assigning a symbol to

//   Value *node = makeNull();

//   node = cons(car(input), car(cdr(input)));
  
// }

//(if (if #t #f #t) 2 3)
//I don't necessarily understand what we want to return
Value *eval(Value *tree, Frame *frame);
Frame *makeNullFrame();

Value *ifif(Value *tree, Frame *frame){
  if(length(tree) != 3){
    printf("Evaluation Error: not 3 stuffs");
    texit(0);
  }
  
  Value *evalbool = eval(car(tree),frame);
  if (evalbool->type != BOOL_TYPE){
    printf("Evaluation Error: not bool type");
    texit(0);
  }
  if (evalbool->i == 1){
    return eval(car(cdr(tree)),frame);
  } else {
    return eval(car(cdr(cdr(tree))),frame);
  }
}

  /*
  (let ((x 5) (y 7)) x)
   -> tree = ((x 5) (y 7)) x
   -> car(tree) = (x 5) (y 7)
   -> cell = (x 5) (y 7)
   -> cdr(cell) = (y 7)
   -> car(cell) = x 5
   -> cdr(tree) = x

  (let ((x 5)) x)
  (let x 2) -> EVAL ERROR


   make a new frame newFrame
   cell = car(tree);
   while car(tree)->type != Null_type;
    newBinding = cons(car(car(cell)),car(cdr(car(cell))));
    newFrame->bindings = cons(newBinding,newFrame->bindings);
    cell = cdr(cell);

  newFrame->parent = frame;
  eval(cdr(tree),newFrame);
     
   make a cons cell with car = variable and cdr = value
   add that cons cell to car of bindings



  */


  /*
 while(frame != NULL){
    while(bindings->type != NULL_TYPE){
      Value *bargs = car(bindings);
      if((!strcmp(car(bargs)->s,symbol->s))){
        return cdr(bargs);
      }else{
        bindings = cdr(bindings);
      }
    }
    frame = frame->parent;
    bindings = frame->bindings;
  }
  
  printf("Evaluation Error: symbol undefined");
  texit(0);
  return NULL;
  */
int cellForm(Value *value){
  if(value == NULL){
    return 1;
  }
  if(value->type == NULL_TYPE){
    printf("helloooo");
    return 1;
  }
  // if(value->type != SYMBOL_TYPE)
  // {
  //   return 1;
  // }
  return 0;
}

Value *iflet(Value *tree, Frame *frame){
  Value *newBinding;
  newBinding = makeNull();
  Frame *newFrame = makeNullFrame();
  //((x 5)) 1 2 3
  //newFrame = makeNullFrame();
  Value *cell;
  cell = makeNull();
  cell = car(tree);
  // display(car(tree));
  if(car(cdr(tree)) == NULL){
       printf("Evaluation Error: empty let");
      texit(0);
    }
  while (cell->type != NULL_TYPE){
    if(cell->type != CONS_TYPE){
      printf("Evaluation Error: wrong cell type");
      texit(0);
    }
    if(car(cell)->type == SYMBOL_TYPE){
      if(cellForm(cdr(cell))){
        printf("Evaluation Error: wrong cell form");
        texit(0);
      } 
    }
    if(car(cell)->type != CONS_TYPE){
      printf("Evaluation Error: wrong cell form");
      texit(0);
    }
    if(length(car(cell))!= 2){
      printf("Evaluation Error: wrong cell length");
      texit(0);
    }
    if(newFrame->bindings->type != NULL_TYPE && lookupSymbolTwo(car(car(cell)), newFrame->bindings, frame)){
      printf("Evaluation Error: duplicate variable in let");
      texit(0);
    }
    if(car(car(cell))->type != SYMBOL_TYPE){
      printf("Evaluation Error: first cell value not symbol type");
      texit(0);
    }
    if(car(cdr(car(cell)))->type == SYMBOL_TYPE){
      newBinding = cons(car(car(cell)),lookupSymbol(car(cdr(car(cell))),frame->bindings,frame));
    }else{
      newBinding = cons(car(car(cell)),car(cdr(car(cell))));
    }
    //lookupSymbol(tree,frame->bindings, frame);
    newFrame->bindings = cons(newBinding,newFrame->bindings);
    
    
    cell = cdr(cell);
  }
  Value *Ret = tree;
  while (cdr(Ret)->type != NULL_TYPE){
    Ret = cdr(Ret);
  }
  
  newFrame->parent = frame;
  return eval(car(Ret),newFrame);
}

//(let ((x 5)) 1 2 3)

Value *eval(Value *tree, Frame *frame) {
  //Value *new_node = makeNull();
  //Value *return_tree = makeNull();
  //recursively evaluate entire tree

  if (tree->type == NULL_TYPE){
    texit(0);
    return NULL;
  }
  // 1 2 (if #t (if a b c) 3)
  switch(tree->type){
    case INT_TYPE:
      return tree;
      
    case DOUBLE_TYPE:
      return tree;

    case STR_TYPE:
      return tree;

    case SYMBOL_TYPE:
      return lookupSymbol(tree,frame->bindings, frame);
    
    case BOOL_TYPE:
      return tree;

    case CONS_TYPE:
      if (!strcmp(car(tree)->s,"if")){
        return ifif(cdr(tree), frame);
      } else if (!strcmp(car(tree)->s,"let")){
        return iflet(cdr(tree), frame);
      } else{
        printf("ERROR: cons type error\n");
        texit(0);
      }

    default: 
      return NULL;
  }






  // switch(car(tree)->type){
  //   case STR_TYPE  :
  //   // fprintf(stdout,"%s\"",car(tree)->s);
  //   return car(tree);
  //   break; 
  //   case INT_TYPE  :
  //   // fprintf(stdout,"%i",car(tree)->i);
  //   return car(tree);
    
  //   break; 
  //   case DOUBLE_TYPE  :
  //   // fprintf(stdout,"%f",car(tree)->d);
  //   return car(tree);
  //   break; 
  //   case SYMBOL_TYPE  :
  //   //check if == 'if'

  //   //first check to see if symbol is a variable by looking through the frame
  //     //if so, print the value stored there
  //   //check if it's "if" or "let"
  //     //if it is, uuhhh, do some more work to make sure we're not printing the cases that don't work

  //   //we're supposed to do something like "LookupSymbol" here but
  //   if (car(cdr(cdr(tree))) != NULL){
  //     if (strcmp(car(tree)->s,"let") && strcmp(car(tree)->s,"if")){
  //       if (lookupSymbol(car(cdr(tree)), frame->bindings, frame)){
  //         // fprintf(stdout,"%s",car(cdr(cdr(tree)))->s);
  //         return car(cdr(tree));
  //       } 
  //     } else if (!strcmp(car(tree)->s,"if")){
  //       //go through frames to check if it's a variable
  //       if (car(cdr(cdr(cdr(tree)))) != NULL){
  //         if (isTrue(car(cdr(tree)))){
  //           Value *new_Tree = makeNull();
  //           Value *temp = car(cdr(cdr(tree)));
  //           tree = cons(temp,new_Tree);
  //           // tree = cdr(cdr(tree));
  //           // tree = cons(temp, tree);
  //           return eval(tree, frame);
  //         } else {
  //           return eval(cdr(cdr(cdr(tree))), frame);
  //         }
  //       }else{
  //         printf("ERROR");
  //         texit(0);
  //       }
  //     } else if (!strcmp(car(tree)->s,"let")){
  //       fprintf(stdout,"%s",car(cdr(cdr(tree)))->s);
  //     }
  //   }
  //   break; 
  //   case OPEN_TYPE  :
  //   //
  //   break; 
  //   case CLOSE_TYPE :
  //   //
  //   break; 
  //   case PTR_TYPE  :
  //   //
  //   break; 
  //   case BOOL_TYPE  :
  //   if (car(tree)->i == 0){
  //     fprintf(stdout,"#f");
        
  //   } else {
  //     fprintf(stdout,"#t");
  //   }
  //   break; 
  //   case DOT_TYPE  :
  //   //
  //   break; 
  //   case NULL_TYPE  :
  //   //
  //   break; 
  //   case SINGLEQUOTE_TYPE  :
  //   //
  //   break; 
  //   case OPENBRACKET_TYPE  :
  //   //
  //   break; 
  //   case CONS_TYPE  :
  //     eval(car(tree),frame);
  //     if (!strcmp(car(tree)->s,"if")){
  //       if ((car (eval(car(cdr (tree)), frame)))->i == 1){
  //         return eval(car(cdr(cdr (tree))),frame);
  //       } else {
  //         return eval(car( cdr( cdr( cdr(tree)))),frame);
  //       }
  //     } else if (!strcmp(car(tree)->s,"let")){
  //       frame = talloc(sizeof(frame));
  //       Value *newBinding = makeNull();
  //       Frame *newFrame;
  //       newFrame->parent = frame;
  //       frame = newFrame;
  //       newBinding = cons(car(cdr(tree)),car(cdr(cdr(tree))));
  //       frame->bindings = cons(newBinding, frame->bindings);
  //       return eval(cdr(tree),newFrame);
  //       //newBinding = makeNull();
  //     } else{
  //       printf("ERROR\n");
  //       texit(0);
  //     }
  //     break; 
  //   case CLOSEBRACKET_TYPE  :
  //   //
  //   break; 
  //   case VOID_TYPE :
  //   printf("ERROR: VOIDTYPE");
  //   texit(0);
  //   break;
  // }
  // // tree = cdr(tree);
  // // return eval(tree,frame);
  // printf("SHOULD NOT BE HERE");
  // texit(-1);
  // return NULL;
}

  //switch statement identifying the types of the nodes in the tree

  //if it's an int, just return(?) the int

  //if it's a bool, just return(?) the bool

  //if it's a string literal, just return(?) the string literal

  //if it's a double, just return(?) the double



  //if its a string:
    //check if the string == 'let' or 'define' or 'if'
    
    //if string === 'let':
      //create new subtree in frame
      //add node w/ variable name
      //add node w/ variable value

    //if string === 'define':
      //create new subtree in frame
      //add node w/ variable name
      //add node w/ variable value

    //if string === 'if':
      //create new subtree in frame
      //add node w/ 'if' as symbol
      //add separate nodes for all the arguments
      //call evalIf() to determine if the if statement is accurate
      //do something with that info???

Frame *makeNullFrame(){

  Frame *frame;
  Value *newBinding = makeNull();
  frame = talloc(sizeof(frame));
  frame->bindings = newBinding;

  // frame->parent = NULL;

  return frame;
}

void displayEval(Value *result){
  switch(result->type){
      case STR_TYPE  :
      fprintf(stdout,"%s\"\n",result->s);
      break; 
      case INT_TYPE  :
      fprintf(stdout,"%i\n",result->i);
      break; 
      case DOUBLE_TYPE  :
      fprintf(stdout,"%f\n",result->d);
      break; 
      case SYMBOL_TYPE  :
      fprintf(stdout,"%s\n",result->s);
      break; 
      case OPEN_TYPE  :
      fprintf(stdout,"(:open\n");
      break; 
      case CLOSE_TYPE  :
      fprintf(stdout,"):close\n");
      break; 
      case PTR_TYPE  :
      fprintf(stdout,"POINTER\n");
      break; 
      case BOOL_TYPE  :
      if (result->i == 0){
        fprintf(stdout,"#f");
      } else {
        fprintf(stdout,"#t");
      }
      break; 
      case DOT_TYPE  :
      fprintf(stdout,".\n");
      break; 
      case NULL_TYPE  :
      fprintf(stdout,"()");
      break; 
      case SINGLEQUOTE_TYPE  :
      fprintf(stdout," \" \n");
      break; 
      case OPENBRACKET_TYPE  :
      fprintf(stdout,"{\n");
      break; 
      case CONS_TYPE  :
      fprintf(stdout,"CONS\n");
      break; 
      case CLOSEBRACKET_TYPE  :
      fprintf(stdout,"}\n");
      break; 
      case VOID_TYPE  :
      fprintf(stdout,"ERROR VOIDTYPE\n");
      break;
      default: 
      printf("ERROR\n");
      break;
    }
}


void interpret(Value *tree){

  Frame *frame;
  frame = makeNullFrame();
  while(tree->type != NULL_TYPE){
    Value *result = eval(car(tree), frame);
    // display(result);
    //printf("%i\n", result->i);
    displayEval(result);
    tree = cdr(tree);
  }
  texit(0);
}
