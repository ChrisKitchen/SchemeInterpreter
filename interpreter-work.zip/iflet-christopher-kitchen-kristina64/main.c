#include <stdio.h>
#include "tokenizer.h"
#include "value.h"
#include "linkedlist.h"
#include "parser.h"
#include "talloc.h"
#include "interpreter.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

int main() {
   Value *list = tokenize(stdin);



   Value *tree = parse(list);
   interpret(tree);

   tfree();
   return 0;
}
