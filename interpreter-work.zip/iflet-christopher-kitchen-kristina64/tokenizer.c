#include <stdio.h>
#include "tokenizer.h"
#include "value.h"
#include "linkedlist.h"
#include "talloc.h"
// #import "sys"

//boolean, integer, float, string, symbol, open, close
Value *tokens;

char number[10] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
char later_symbols[80] = {'!', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '$', '%', '&', '*', '/', ':', '<','+', '>', '?', '~', '_', '^', '.', '+','-','0', '1', '2', '3', '4', '5', '6', '7', '8', '9','='};
char symbols[67] = {'!', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '$', '%', '&', '*', '/', ':', '<','+', '>', '?', '~', '_', '^','='};

//'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'

// <identifier> ->  <initial> <subsequent>* | + | -
// <initial>    ->  <letter> | ! | $ | % | & | * | / | : | < | = | > | ? | ~ | _ | ^
// <subsequent> ->  <initial> | <digit> | . | + | -
// <letter>     ->  a | b | ... | z | A | B | ... | Z
// <digit>      ->  0 | 1 | ... | 9 


//A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z
bool in(char thing, char *lst, int length){

  for (int i = 0; i < length; i++){
    if (lst[i] == thing){
      return true;
    }
  }
  return false;
}

char *createArray(Value *sub_ll){
  char *sub_Array;
  int i = 0;
  sub_Array = talloc(sizeof(char) *(length(sub_ll)+1));
  sub_ll = reverse(sub_ll);
  while (sub_ll->type != NULL_TYPE){
    //fprintf(stdout,"test int %u\n",car(sub_ll)->i);
    //fprintf(stdout,"test int char %c\n",(char) car(sub_ll)->i);
    sub_Array[i] = (char) car(sub_ll)->i;
    sub_ll = cdr(sub_ll);
    i++;
  }
  //sub_Array = talloc(sizeof(i));
  sub_Array[i]=0;
  return sub_Array;
}

/*
char[] sub_array;
sub_array = talloc(sizeof(char) * (length(whatever) +1));
*/

Value *tokenize(){
  tokens = makeNull();
  Value *node = makeNull();
  FILE *file = stdin;
  int i;
  char the_cha = (char) i; //most recently read character 
  char *sub_Array;

  bool prev_char_was_boolean = false;
  bool cur_in_str = false;
  bool cur_in_symbol = false;
  bool cur_in_int = false;
  bool cur_in_double = false;
  bool cur_in_comment = false;

  Value *sub_ll = makeNull();
  //Value *node_ll;

  while ((i = fgetc(file)) != EOF){
    char the_cha = (char) i;  
    if (cur_in_comment){
      if (the_cha == '\n'){
        cur_in_comment = false;
      }
    } else if(cur_in_double){
      if(the_cha == '.'){
        fprintf(stdout, "ERROR");
        texit(0);
      } else if(in(the_cha, number, 10)){
        // add to double;
        //add to the sub linked list
        node->i = the_cha;
        sub_ll = cons(node, sub_ll);
        node->type = DOUBLE_TYPE;
        node = makeNull();
      } else if(the_cha == ' ' || the_cha == '\n'){
        //store double;
        //createArray then add to big linked list
        sub_Array = createArray(sub_ll);
        //zero out sub linked list
        node->d = strtod(sub_Array, NULL);
        tokens = cons(node, tokens);
        node->type = DOUBLE_TYPE;

        sub_ll = makeNull();
        cur_in_double = false;
        node = makeNull();
      } else if(the_cha == ')'){
        //store double ;
        sub_Array = createArray(sub_ll);
        //zero out sub linked list
        node->d = strtod(sub_Array, NULL);
        tokens = cons(node, tokens);
        node->type = DOUBLE_TYPE;

        sub_ll = makeNull();
        cur_in_double = false;
        // store close_type;
        node = makeNull();
      } else {
        fprintf(stdout,"Error in double, unrecognized %c\n", the_cha);
        texit(0);
      }
  } else if(cur_in_int){
    if(the_cha == '.'){
      cur_in_int = false;
      cur_in_double = true;

      //add to the sub linked list
      node->i = the_cha;
      sub_ll = cons(node, sub_ll);
      node->type = DOUBLE_TYPE;
      node = makeNull();
    } else if (in(the_cha, number, 10)){
      //add to the sub linked list

      node->i = the_cha;
      sub_ll = cons(node, sub_ll);
      node->type = INT_TYPE;
      node = makeNull();
    } else if (the_cha == ' ' || the_cha == '\n') {
      //store int;
      //createArray from the sub_ll
      //cast the array to in
      sub_Array = createArray(sub_ll);
      node->i = atoi(sub_Array);
      tokens = cons(node, tokens);
      node->type = INT_TYPE;
      cur_in_int = false;
      node = makeNull();
      sub_ll = makeNull();
    } else if (the_cha == ')' ){
    //store open_type
      sub_Array = createArray(sub_ll);
      node->i = atoi(sub_Array);
      tokens = cons(node, tokens);
      node->type = INT_TYPE;
      cur_in_int = false;
      node = makeNull();
      sub_ll = makeNull();
      
      tokens = cons(node, tokens);
      node->type = CLOSE_TYPE;
      node = makeNull();

    } else {
      fprintf(stdout,"Error in int, unrecognized %c\n", the_cha);
      texit(0);
    }
  } else if(cur_in_symbol){
    if(in(the_cha, number, 10) || in(the_cha, later_symbols, 80)){//check if valid character
      //add to symbol
      node->i = the_cha;
      sub_ll = cons(node, sub_ll);
      node->type = SYMBOL_TYPE;
      node = makeNull();
    } else if(the_cha == ' ' || the_cha == '\n'){
      //save symbol_type
      sub_Array = createArray(sub_ll);
      //display(car(sub_ll));
      //fprintf(stdout,"test char: %c\n",sub_Array[0]);
      node->s = sub_Array;
      tokens = cons(node, tokens);
      node->type = SYMBOL_TYPE;
      //fprintf(stdout,"test: %s\n",node->s);
      cur_in_symbol = false;
      node = makeNull();
      sub_ll = makeNull();
    } else if(the_cha == '('){//missing close type
      //store symbol
      //store open_type
      sub_Array = createArray(sub_ll); 
      node->s = sub_Array;
      tokens = cons(node, tokens);
      node->type = SYMBOL_TYPE;
      cur_in_symbol = false;
      node = makeNull();
      sub_ll = makeNull();

      tokens = cons(node, tokens);
      node->type = OPEN_TYPE;
      node = makeNull();
    } else if(the_cha == ')'){
      //store symbol_type
      //store close_type
      sub_Array = createArray(sub_ll);
      node->s = sub_Array;
      tokens = cons(node, tokens);
      node->type = SYMBOL_TYPE;
      cur_in_symbol = false;
      node = makeNull();
      sub_ll = makeNull();

      tokens = cons(node, tokens);
      node->type = CLOSE_TYPE;
      node = makeNull();
    } else{
      fprintf(stdout,"Error in symbol, unrecognized %c\n", the_cha);
      texit(0);
    }
  } else if (cur_in_str){
    //store in str array
    if (the_cha == '"'){
      //store str in big linked list
      //add " to str
      sub_Array = createArray(sub_ll);
      node->s = sub_Array;
      tokens = cons(node, tokens);
      node->type = STR_TYPE;
      cur_in_str = false;
      node = makeNull();
      sub_ll = makeNull();
    } else{
      //add to str
      node->i = the_cha;
      sub_ll = cons(node, sub_ll);
      node->type = STR_TYPE;
      node = makeNull();
    }

  } else if (prev_char_was_boolean){ //last of cur_ins -------------------------------------------------------------------------------------------------------------------
    if(the_cha == 't'){
      //store boolean true
      node->i = 1;
      tokens = cons(node, tokens);
      node->type = BOOL_TYPE;
      node = makeNull();
      prev_char_was_boolean = false;
    }
    else if (the_cha == 'f'){
      //store boolean false
      node->i = 0;
      tokens = cons(node, tokens);
      node->type = BOOL_TYPE;
      node = makeNull();
      prev_char_was_boolean = false;

    } else{
      fprintf(stdout,"ERROR");
      texit(0);
    } //ends here
  } else if (the_cha == '(' ){
    //store open_type

    tokens = cons(node, tokens);
    node->type = OPEN_TYPE;
    node = makeNull();

  } else if (the_cha == ')' ){
    //store close_type

    tokens = cons(node, tokens);
    node->type = CLOSE_TYPE;
    node = makeNull();

  } else if (the_cha == '#'){
    prev_char_was_boolean = true;
    //add # char


  } else if (the_cha == '"') {
      node->i = the_cha;
      sub_ll = cons(node, sub_ll);
      node->type = STR_TYPE;
      node = makeNull();
    if (cur_in_str == true) {
      cur_in_str = false;
      sub_Array = createArray(sub_ll);
      node->s = sub_Array;
      node->type = STR_TYPE;
      tokens = cons(node, tokens);
      node = makeNull();
      sub_ll = makeNull();
    } else{
      cur_in_str = true;
    }
  } else if (in(the_cha, symbols, 67)){
    cur_in_symbol = true;
    node->i = the_cha;
    node->type = SYMBOL_TYPE;
    sub_ll = cons(node,sub_ll); //???????????????????? does this work???????????????????????????????????
    node = makeNull();
  } else if (the_cha == '-' || the_cha == '+'){
    int j = fgetc(file);
    if (in((char) j, number, 10)){
      cur_in_int = true;
      node->i = the_cha;
      node->type = INT_TYPE;
      sub_ll = cons(node, sub_ll);
      node = makeNull();
   } else if (j == '\n' || j == ')' || j == ' '){
     char *array_here = malloc(sizeof(the_cha)*2);
     array_here[0] = the_cha;
    //  array_here[1] = NULL;
     node->s = array_here;
     node->type = SYMBOL_TYPE;
     tokens = cons(node, tokens);
     node = makeNull();
     //sub_ll = makeNull();
   } else {
     fprintf(stdout,"ERROR");
   }
    ungetc(j,file);
  } else if (in(the_cha, number, 10)){
        cur_in_int = true;
        node->i = the_cha;
        node->type = INT_TYPE;
        sub_ll = cons(node, sub_ll);
        node = makeNull();
  } else if (the_cha == ';'){
    cur_in_comment = true;
  } else if (the_cha != ' ' && the_cha != '\n'){
    fprintf(stdout,"ERROR %c", the_cha);
    texit(0);
  }

}
return reverse(tokens);
}





//read scheme code, return linked list of file w/ their types (above)
//ignore anything after a semicolon



// Value *tokenize(){
  
//   //char symbols[5]; //put all the symbols in here
  
// //grab input from file
//   // FILE *file = fopen(stdin, "r");
//   FILE *file =  stdin;
  
//   if(file == NULL){
//     return NULL;
//   }
  
//   char *c;
//   int i;
//   size_t s = 0;
//   c = malloc(1000);
//   while ((i = fgetc(file)) != EOF)
//   {
//     c[s++] = (char) i;
//     switch(typeof(c[i])){
//     //add char to linkedlist with its type
//       case  SYMBOL_TYPE  :
//       cons(c[i], tokens);
//       // car(c[i])->type = STR_TYPE;
//       break; 
//       case  INT_TYPE  :
//       cons(c[i], tokens);
//       // car(list)->type = INT_TYPE;
//       break; 
//       case DOUBLE_TYPE  :
//       cons(c[i], tokens);
//       // car(list)->type = FLOAT_TYPE;
//       break; 
//       case OPENBRACKET_TYPE :
//       cons(c[i], tokens);
//       break;
//       case SINGLEQUOTE_TYPE :
//       cons(c[i], tokens);
//       break;
//       case CLOSEBRACKET_TYPE :
//       cons(c[i], tokens);
//       break;

//     }

//     switch(c[i]){
//       case c[i] in symbols  :
//       cons(c[i], list);
//       car(list)->type = SYMBOL_TYPE;
//       break; 
//       case c[i] == '('  :
//       cons(c[i], list);
//       car(list)->type = OPEN_TYPE;
//       break; 
//       case ')'  :
//       cons(c[i], list);
//       car(list)->type = CLOSE_TYPE;
//       break; 
//     //take first char out of lexemes
//     }
//   }

  // c[s] =  "/0";
  
//   fscanf(lexemes, "%c", c);
// //iterate through file stuff
//   while(lexemes != NULL){
//     //save first char of lexemes and check it out
//     //switch statement with each type the char could be
    
//   }

// //return the full linkedlist
// }

void displayTokens(Value *list){

   while(list->type != NULL_TYPE){

    // fprintf(stdout,"%s",car(list)->s);
    switch(car(list)->type){
      case STR_TYPE  :
      fprintf(stdout,"%s\":string\n",car(list)->s);
      break; 
      case INT_TYPE  :
      fprintf(stdout,"%i:integer\n",car(list)->i);
      break; 
      case DOUBLE_TYPE  :
      fprintf(stdout,"%f:double\n",car(list)->d);
      break; 
      case SYMBOL_TYPE  :
      fprintf(stdout,"%s:symbol\n",car(list)->s);
      break; 
      case OPEN_TYPE  :
      fprintf(stdout,"(:open\n");
      break; 
      case CLOSE_TYPE  :
      fprintf(stdout,"):close\n");
      break; 
      case PTR_TYPE  :
      fprintf(stdout,"POINTER\n");
      break; 
      case BOOL_TYPE  :
      if (car(list)->i == 0){
        fprintf(stdout,"#f:boolean\n");
      } else {
        fprintf(stdout,"#t:boolean\n");
      }
      break; 
      case DOT_TYPE  :
      fprintf(stdout,"DOT\n");
      break; 
      case NULL_TYPE  :
      fprintf(stdout,"NULL\n");
      break; 
      case SINGLEQUOTE_TYPE  :
      fprintf(stdout,"QUOTE\n");
      break; 
      case OPENBRACKET_TYPE  :
      fprintf(stdout,"OPENBRACKET\n");
      break; 
      case CONS_TYPE  :
      fprintf(stdout,"CONS\n");
      break; 
      case CLOSEBRACKET_TYPE  :
      fprintf(stdout,"CLOSEBRACKET\n");
      break; 
      case VOID_TYPE :
      fprintf(stdout,"VOID");
      break;
    }

    list = cdr(list);
}

}

