#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "linkedlist.h"
#include "value.h"
//#include "main.c"

Value *makeNull(){
  Value *node;
  node = malloc(sizeof(Value));
  node->type = NULL_TYPE;
  return node;
}

Value *cons(Value *newCar, Value *newCdr){
  Value *node;
  node = malloc(sizeof(Value));
  node->type = CONS_TYPE;
  //node->c.car = malloc(sizeof(node->c.car));
  //node->c.cdr = malloc(sizeof(node->c.cdr));
  node->c.car = newCar;
  node->c.cdr = newCdr;
  
  return node;
}

Value *copynode(Value *node){
  Value *new_node;
  new_node = malloc(sizeof(Value));
  *new_node = *node;
  return new_node;
}

Value *car(Value *list){
  return list->c.car;
}

Value *cdr(Value *list){
  return list->c.cdr;
}

Value *reverse(Value *list){
  Value *linkedList = makeNull();
  //Value *cur_node = car(list);
  

  while(list->type != NULL_TYPE){
    Value *new_node;
    //new_node = malloc(sizeof(new_node)); malloc(strlen())
    new_node = cons(copynode(car(list)), linkedList);
    new_node->type = list->type; 

    if(car(new_node)->type == STR_TYPE){
      car(new_node)->s = malloc(strlen(car(list)->s) + 1);
      strcpy(car(new_node)->s, car(list)->s);
    }
    list = cdr(list);
    linkedList = new_node;
  }

  return linkedList;
}

void display(Value *list){
  //Value *cur_node = car(list);
  while(list->type != NULL_TYPE){
    // printf("node %p \n", car(cur_node));
    printf("the contents of cur_node are: ");
    switch(car(list)->type){
      case STR_TYPE  :
      printf("%s\n",car(list)->s);
      break; 
      case INT_TYPE  :
      printf("%i\n",car(list)->i);
      break; 
      case DOUBLE_TYPE  :
      printf("%f\n",car(list)->d);
      break; 
      case NULL_TYPE  :
      printf("NULL\n");
      break; 
      case CONS_TYPE  :
      printf("CONS\n");
      break; 
    }

    // printf("node test \n");
    // printf("the cur_node is: %p\n", list);
    // printf("the cdr is: %p\n", cdr(list));
    list = cdr(list);
  }
}

//INT_TYPE,DOUBLE_TYPE,STR_TYPE,CONS_TYPE,NULL_TYPE
/*
switch(var):
  case "a":
    do x;
    break;
  case "b":
  case "c":
    do sdfds;
    break;

*/

bool isNull(Value *value){
  if (value->type == NULL_TYPE){
    return true;
  }
  return false;
}

void cleanup(Value *list){
  //Value *cur_node = car(list);
  Value *temp_node;
  while(list->type != NULL_TYPE){
    if (car(list)->type == STR_TYPE){
      free(car(list)->s);
    }
    temp_node = cdr(list);
    free(car(list));
    free(list);
    list = temp_node;
  }

  assert(list != NULL);
  
  free(list);
}


int length(Value *value){
  int counter = 0;
  //Value *cur_node = car(value);
  while(value->type != NULL_TYPE){
    value = cdr(value);
    counter++;
  }
  return counter;
}

/*
make new reverse_list = NULL_TYPE
make cur_node = first in list
 go to while loop
  
  take current value of list taken in, starting at the first value
  redefine cur_node to next one in the list
  have cur_node point to previous cur_node
  add it to an empty list
  



*/
