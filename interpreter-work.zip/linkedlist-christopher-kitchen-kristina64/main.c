// Tester for linked list. Note that this does not test all the functionality
// you implemented; you should enhance it significantly. We will test your
// linked list code with a different main.c.

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "linkedlist.h"
#include "value.h"

void testForward(Value *head) {
   Value *value = head;
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(1 == car(value)->d);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("2.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("3.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(4 == car(value)->d);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("5.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(6 == car(value)->d);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(INT_TYPE == car(value)->type);
   assert(7 == car(value)->i);

   value = cdr(value);
   assert(NULL_TYPE == value->type);

   assert(7 == length(head));
   assert(!isNull(head));
}

void testBackward(Value *head) {
   Value *value = head;

   assert(CONS_TYPE == value->type);
   assert(INT_TYPE == car(value)->type);
   assert(7 == car(value)->i);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(6 == car(value)->d);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("5.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(4 == car(value)->d);

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("3.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(STR_TYPE == car(value)->type);
   assert(!strcmp("2.0s", car(value)->s));

   value = cdr(value);
   assert(CONS_TYPE == value->type);
   assert(DOUBLE_TYPE == car(value)->type);
   assert(1 == car(value)->d);

   value = cdr(value);
   assert(NULL_TYPE == value->type);

   assert(7 == length(head));
   assert(!isNull(head));
}


int main() {
    Value *val1 = malloc(sizeof(Value));
    val1->type = INT_TYPE;
    val1->i = 7;

    Value *val2 = malloc(sizeof(Value));
    val2->type = DOUBLE_TYPE;
    val2->d = 6.00;

    Value *val3 = malloc(sizeof(Value));
    val3->type = STR_TYPE;
    char *text = "5.0s";
    val3->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(val3->s,text);

    Value *val4 = malloc(sizeof(Value));
    val4->type = DOUBLE_TYPE;
    val4->d = 4.00000;

    
    Value *val5 = malloc(sizeof(Value));
    val5->type = STR_TYPE;
    text = "3.0s";
    val5->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(val5->s,text);

    Value *val6 = malloc(sizeof(Value));
    val6->type = STR_TYPE;
    text = "2.0s";
    val6->s = malloc(sizeof(char)*(strlen(text) + 1));
    strcpy(val6->s,text);

    Value *val7 = malloc(sizeof(Value));
    val7->type = DOUBLE_TYPE;
    val7->d = 1.0;

    Value *head = makeNull();
    head = cons(val1,head);
    head = cons(val2,head);
    head = cons(val3,head);
    head = cons(val4,head);
    head = cons(val5,head);
    head = cons(val6,head);
    head = cons(val7,head);
    
    display(head);
    testForward(head);

    Value *rev = reverse(head);
    display(rev);

    testBackward(rev);

    cleanup(head);
    cleanup(rev);

    head = NULL;
    rev = NULL;
}
